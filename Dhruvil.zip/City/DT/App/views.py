from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request,'main.html')

def india(request):
    return render(request,'india.html')


def wi(request):
    return render(request,'wi.html')

def australia(request):
    return render(request,'australia.html')

def nz(request):
    return render(request,'nz.html')

def sa(request):
    return render(request,'sa.html')

def zim(request):
    return render(request,'zim.html')

def sl(request):
    return render(request,'sl.html')