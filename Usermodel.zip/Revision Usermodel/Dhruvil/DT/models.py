from django.db import models

# Create your models here.
class Usermodel(models.Model):
    Name = models.CharField(max_length=30)
    Age = models.IntegerField()
    Address = models.TextField()

    def __str__(self):
        return self.Name