from django.shortcuts import render,redirect
from .models import Usermodel
from .forms import Userform
# Create your views here.
def display(request):
    data = Usermodel.objects.all()
    return render(request,'Display.html',{'data':data})

def home(request):
    return render(request,'Home.html')

def add(request):
    if request.method == 'POST':
        form = Userform(request.POST)
        form.save()
        return redirect('display')
    else:
        form=Userform()
    return render(request,'Add.html',{'form':form})

def edit(request,id):
    data = Usermodel.objects.get(id=id)
    if request.method =='POST':
        form = Userform(request.POST,instance=data)
        form.save()
        return redirect('display')
    else:
        form = Userform(instance=data)
    return render(request,'Edit.html',{'form':form})

def delete(request,id):
    data = Usermodel.objects.get(id=id)
    data.delete()
    data = Usermodel.objects.all()
    return render(request, 'Display.html', {'data': data})