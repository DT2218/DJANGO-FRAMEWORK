from django.contrib import admin
from .models import Usermodel
# Register your models here.
admin.site.register(Usermodel)