from django.shortcuts import render


# Create your views here.
def home(request):
    return render(request, 'main.html')


def india(request):
    return render(request, 'india.html')


def gujarat(request):
    return render(request, 'gujarat.html')


def gandhinagar(request):
    return render(request, 'gandhinagar.html')


def maharashtra(request):
    return render(request, 'maharashtra.html')


def mumbai(request):
    return render(request, 'mumbai.html')


def karnataka(request):
    return render(request, 'karnataka.html')


def bengalure(request):
    return render(request, 'bengalure.html')


def australia(request):
    return render(request, 'australia.html')


def southwales(request):
    return render(request, 'southwales.html')


def sydney(request):
    return render(request, 'sydney.html')


def queensland(request):
    return render(request, 'queensland.html')


def brisbane(request):
    return render(request, 'brisbane.html')


def southas(request):
    return render(request, 'southas.html')


def adelaide(request):
    return render(request, 'adelaide.html')


def tsamnia(request):
    return render(request, 'tsamnia.html')


def hobart(request):
    return render(request, 'hobart.html')


def america(request):
    return render(request, 'america.html')


def california(request):
    return render(request, 'california.html')


def sacramento(request):
    return render(request, 'sacramento.html')


def florida(request):
    return render(request, 'florida.html')


def tallahassee(request):
    return render(request, 'tallahassee.html')


def georgia(request):
    return render(request, 'georgia.html')


def atlanta(request):
    return render(request, 'atlanta.html')