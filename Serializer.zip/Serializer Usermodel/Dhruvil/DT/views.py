from django.shortcuts import render
from django.http import JsonResponse
from .serializers import Userserializers
from rest_framework.response import Response
from .models import Usermodel

# Create your views here.
def user(request):
    user = Usermodel.objects.all()
    serializers = Userserializers(user,many=True)
    return JsonResponse({'user':serializers.data},safe=False)

def user_id(request,id):
    user = Usermodel.objects.get(id=id)
    serializers = Userserializers(user)
    return Response(serializers.data)
