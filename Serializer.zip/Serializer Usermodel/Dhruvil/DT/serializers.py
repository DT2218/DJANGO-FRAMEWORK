from rest_framework import serializers
from .models import Usermodel

class Userserializers(serializers.ModelSerializer):
    class Meta:
        model = Usermodel
        fields = '__all__'