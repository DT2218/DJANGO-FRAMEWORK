from django.db import models

# Create your models here.
class Usermodel(models.Model):
    Fname = models.CharField(max_length=30)
    Lname = models.CharField(max_length=30)
    Age =  models.IntegerField()

    def __str__(self):
        return self.Fname